import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {


  constructor() {
    
   }
   users:any[]=[
    {id:1010, name:"Sajib", password:123},
    {id:1020, name:"Rajib", password:1234}
  ];

   public getUsers(){
    return this.users;
   }
   public data:any;

}
