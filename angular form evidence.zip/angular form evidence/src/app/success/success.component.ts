import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  constructor(private myService:LoginServiceService) {
    this.xyz=this.myService.data;
   }
  xyz:any;

  ngOnInit(): void {
  }

}
