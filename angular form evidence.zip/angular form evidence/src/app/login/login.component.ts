import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router, private myServise:LoginServiceService) { }

  id:any=0;
  name:string="";
  password:any=0;
  user:any={};
  p:any[]=[];



  login(){
    this.p=this.myServise.getUsers().slice();

    this.user=this.p.find(x=>(x.id==this.id)&& (x.password==this.password)) ; 
    if (this.user!=null) {
      this.myServise.data=this.user;
      this.router.navigateByUrl("success");    
    } else {
      this.router.navigateByUrl("fail");  
      
    }

  }

  ngOnInit(): void {
  }

}
